function setup() {

	createCanvas(800,400);
	background(240);

	translate(400, 200);
	ellipse(0,0,20,20);

	noFill();
	arc(0,0,60,60, PI / 16, -PI / 16, PIE);


}
