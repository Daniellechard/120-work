function setup() {
    createCanvas( 600, 400 );
    background( '#d1d1d1' );
}

function draw() {
    arc( 300, 200, 300, 300, radians(260), radians(280) );
}
