function setup() {
    createCanvas( 500, 400 );
    background( '#e3f9c8' );
}

function draw() {
    // a rectangle with various corner roundness
    rect( 20, 20, 300, 300, 0, 90, 45, 150 );
}
