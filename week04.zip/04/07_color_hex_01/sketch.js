function setup() {
    // first we need to specify our canvas size
    createCanvas( 800, 400 );

    // Try changing any of the characters after the `#`
    // Remember to keep them values between 0-f
    // [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f].
    background( '#ff00ff' );
}
