function setup() {
    createCanvas( 500, 600 );
    background( '#e3f9c8' );
}

function draw() {
    rect( 25, 30, 450, 540);
}
