function setup() {
    createCanvas( 300, 100 );
    background( '#c8f1f9' );
}

function draw() {
    point( 100, 50 );
}
